-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2026. Feb 13. 13:50
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `firms`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `favorites`
--

CREATE TABLE `favorites` (
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `favorites`
--

INSERT INTO `favorites` (`user_id`, `product_id`) VALUES
(4, 1),
(4, 2),
(4, 3);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `firm`
--

CREATE TABLE `firm` (
  `ID` int(11) NOT NULL,
  `brand_name` varchar(50) NOT NULL,
  `worker_name` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `approved` tinyint(1) DEFAULT 0,
  `profile_pic` varchar(255) DEFAULT 'default_firm.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `firm`
--

INSERT INTO `firm` (`ID`, `brand_name`, `worker_name`, `email`, `password`, `approved`, `profile_pic`) VALUES
(1, 'HARIBO', '', 'haribo.og@gmail.com', '$2y$10$vNU0lh7ZY0AhpY9JBIISVerfn83r5jLd7c16mlmB6IKm51F2OtKEe', 1, 'default_firm.png');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `firm_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_read` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `password_resets`
--

INSERT INTO `password_resets` (`id`, `email`, `token`, `expires_at`, `created_at`) VALUES
(1, 'elsovas@hotmail.com', '9ede4119c09d18057a5bf7093af329558808c8c7afb6ceee851db4a6d70226ee', '2026-02-05 20:20:26', '2026-02-05 18:50:26'),
(2, 'elsovas@hotmail.com', '36eef65e4adeef88338561321208de2f15b58066467c843c1a5f1ecfce1b28b7', '2026-02-05 20:24:28', '2026-02-05 18:54:28');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `products`
--

CREATE TABLE `products` (
  `ID` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `weight` int(8) NOT NULL,
  `amount` int(11) NOT NULL,
  `active` tinyint(1) NOT NULL,
  `type` enum('Zöldség és gyümölcs','Tejtermék- tojás','Pékáru','Húsáru','Mélyhűtött','Alapvető élelmiszerek','Italok','Speciális','Háztartás','Drogéria','Kisállat','Otthon-hobbi') NOT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `firm_id` int(11) DEFAULT NULL,
  `approved` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `products`
--

INSERT INTO `products` (`ID`, `name`, `description`, `price`, `weight`, `amount`, `active`, `type`, `picture`, `firm_id`, `approved`) VALUES
(1, 'Haribo Goldbären gyümölcsízű gumicukorka', 'A Goldbären-t mindenki ismeri – nem véletlenül. Hiszen ez az eredeti és összetéveszthetetlen gumicukorka 1922 óta okoz örömet kicsi és nagy, fiatalabb vagy idősebb rajongók számára. A hat színpompás medvécske – a legfinomabb gyümölcsízekben az ananásztól ', 499.00, 100, 3432, 1, 'Alapvető élelmiszerek', 'letoltes.jpg', 1, 1),
(2, 'Haribo Goldbären gyümölcsízű gumicukorka', 'A Goldbären-t mindenki ismeri – nem véletlenül. Hiszen ez az eredeti és összetéveszthetetlen gumicukorka 1922 óta okoz örömet kicsi és nagy, fiatalabb vagy idősebb rajongók számára. A hat színpompás medvécske – a legfinomabb gyümölcsízekben az ananásztól ', 499.00, 100, 4515, 1, 'Alapvető élelmiszerek', 'letoltes.jpg', 1, 1),
(3, 'Haribo Starmix', 'jjjjjjjjjjjjjjjjj', 890.00, 250, 3, 1, 'Alapvető élelmiszerek', '1770800504_1770198067_Haribo-Starmix-Minis-250g.jpg', 1, 1),
(4, 'Haribo Rainbow Frogs ', 'hhhhhhhhhh', 499.00, 125, 32, 1, 'Alapvető élelmiszerek', '1770800526_1770198732_Harbio_frogs.jpg', 1, 1),
(2147483647, 'HARIBO Tropic Party Size', '', 1800.00, 1000, 4354, 1, 'Alapvető élelmiszerek', '1770806267_haribo-tropusi-gumicukor-1000g.jpg', 1, 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `shopping_list`
--

CREATE TABLE `shopping_list` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `product_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `shopping_list`
--

INSERT INTO `shopping_list` (`id`, `user_id`, `product_id`, `product_price`, `quantity`) VALUES
(7, 3, 3, 890.00, 1),
(8, 4, 2, 499.00, 23),
(38, 4, 1, 499.00, 1);

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `admin` varchar(20) NOT NULL DEFAULT 'user',
  `profile_pic` varchar(255) DEFAULT 'default_user.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `name`, `userName`, `email`, `password`, `admin`, `profile_pic`) VALUES
(1, 'valami', 'valami', 'valami@hotmail.com', '$2y$10$pNVhxRayvnlgreujtjYi0.wBay07v27dr0gkyMMwCE0GtQyeZzKWq', 'user', 'default_user.png'),
(2, 'Kovács Antal', 'thinkjan', 'kovacsan@gmail.com', 'password123', 'user', 'default_user.png'),
(3, 'Admin', 'admin', 'admin@bolt.hu', '$2y$10$w5C0UJMfwkrOUfuKnymCzumLIUJRuPIpYUQUTRAIbIJxJwvWA4Nv6', 'admin', 'default_user.png'),
(4, 'Admin', 'admin', 'admin@bolt.hu', '$2y$10$RAFXEyDNtXTb2mbi8cINj.j6PnZqVh1QJBm3Pt8abT/ZrvIuiZVVi', 'user', 'prof_1769776487.png'),
(5, 'vasarlo1', 'Béla', 'elsovas@hotmail.com', '$2y$10$c9ssHKwXXjWsxganFUwwAO3d96Ai2s4/h9RapOZUCWLn5/kE9e1Z6', 'user', 'prof_1770143785.jpg'),
(7, 'emailtest', 'email', 'gergo.mokan@gmail.com', '$2y$10$VdVK0hd16IWeM0U.qqt6leHiTBg2aJoGQ3mgsU28yQWm0ez2LwCva', 'user', 'default_user.png'),
(8, 'Példa János', 'Janos', 'janos.kis@gmail.com', '$2y$10$iFGGPSmG9/o0hwXBby2BBetCVTHhqfoU7JQa6y.hUxGpNR0NCNx22', 'user', 'default_user.png');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`user_id`,`product_id`),
  ADD UNIQUE KEY `unique_fav` (`user_id`,`product_id`);

--
-- A tábla indexei `firm`
--
ALTER TABLE `firm`
  ADD PRIMARY KEY (`ID`);

--
-- A tábla indexei `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`);

--
-- A tábla indexei `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `firm_id` (`firm_id`),
  ADD KEY `price` (`price`),
  ADD KEY `price_2` (`price`);

--
-- A tábla indexei `shopping_list`
--
ALTER TABLE `shopping_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_id` (`user_id`),
  ADD KEY `fk_product_id` (`product_id`);

--
-- A tábla indexei `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `firm`
--
ALTER TABLE `firm`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT a táblához `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT a táblához `products`
--
ALTER TABLE `products`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2147483648;

--
-- AUTO_INCREMENT a táblához `shopping_list`
--
ALTER TABLE `shopping_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT a táblához `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`firm_id`) REFERENCES `firm` (`ID`);

--
-- Megkötések a táblához `shopping_list`
--
ALTER TABLE `shopping_list`
  ADD CONSTRAINT `fk_list_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_list_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
