<?php
session_start();
include "connect.php";

$base_path = "/Vizsgaremek/";

// JSON választ adunk, ha a kérés Fetch-től (JavaScript) érkezik
$is_ajax = (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') || isset($_GET['ajax']);

if (!isset($_SESSION['user_id'])) {
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'Bejelentkezés szükséges']);
        exit;
    }
    header("Location: " . $base_path . "login");
    exit;
}

$user_id = $_SESSION['user_id'];

// --- KEDVENCEKHEZ ADÁS ---
if (isset($_GET['add_to_fav'])) {
    $p_id = (int)$_GET['add_to_fav'];
    $stmt = $conn->prepare("INSERT IGNORE INTO favorites (user_id, product_id) VALUES (?, ?)");
    $stmt->bind_param("ii", $user_id, $p_id);
    $success = $stmt->execute();
    
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success]);
        exit;
    }
    header("Location: " . $base_path . "index?msg=Kedvencekhez adva!");
    exit;
}

// --- KEDVENC TÖRLÉSE ---
if (isset($_GET['remove_fav'])) {
    $p_id = (int)$_GET['remove_fav'];
    $stmt = $conn->prepare("DELETE FROM favorites WHERE user_id = ? AND product_id = ?");
    $stmt->bind_param("ii", $user_id, $p_id);
    $success = $stmt->execute();
    
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => $success]);
        exit;
    }
    header("Location: " . ($_SERVER['HTTP_REFERER'] ?? $base_path . "index"));
    exit;
}

// --- KOSÁRBA HELYEZÉS ---
if (isset($_GET['add_to_cart'])) {
    $p_id = (int)$_GET['add_to_cart'];

    $check = $conn->prepare("SELECT id FROM shopping_list WHERE user_id = ? AND product_id = ?");
    $check->bind_param("ii", $user_id, $p_id);
    $check->execute();
    $res = $check->get_result();

    if ($res->num_rows > 0) {
        $stmt = $conn->prepare("UPDATE shopping_list SET quantity = quantity + 1 WHERE user_id = ? AND product_id = ?");
        $stmt->bind_param("ii", $user_id, $p_id);
        $success = $stmt->execute();
    } else {
        $get_price = $conn->prepare("SELECT price FROM products WHERE id = ?");
        $get_price->bind_param("i", $p_id);
        $get_price->execute();
        $price_res = $get_price->get_result()->fetch_assoc();

        if ($price_res) {
            $price = $price_res['price'];
            $stmt = $conn->prepare("INSERT INTO shopping_list (user_id, product_id, product_price, quantity) VALUES (?, ?, ?, 1)");
            $stmt->bind_param("iid", $user_id, $p_id, $price);
            $success = $stmt->execute();
        }
    }

    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit;
    }
    header("Location: " . $base_path . "index?msg=Kosárba téve!");
    exit;
}

// ... A darabszám módosítás (update_qty) maradjon az eredeti, mert ott az oldal újratöltése általában szükséges az összegek frissítéséhez ...

header("Location: " . $base_path . "index");
exit;