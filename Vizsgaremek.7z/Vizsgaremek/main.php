// Jogosultság eldöntése: a szerint mit lát
// Admin: miondent lát
// Céges juser: Saját termékeit látja: ejeket tudja módosítani, hozzáadni, soft delete(elérhető- nem elérhető actual)
