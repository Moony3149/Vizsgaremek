<?php
session_start();
include "connect.php";

$role = $_SESSION['admin'] ?? null; 
$user_id = $_SESSION['user_id'] ?? 0;
$firm_id = $_SESSION['firm_id'] ?? null;

// Név ÉS Profilkép lekérése az adatbázisból
$display_name = "";
$profile_pic = "default_user.png"; 

if ($user_id) {
    $stmt_name = $conn->prepare("SELECT username, profile_pic FROM users WHERE ID = ?");
    $stmt_name->bind_param("i", $user_id);
    $stmt_name->execute();
    $res_name = $stmt_name->get_result();
    if ($row_name = $res_name->fetch_assoc()) {
        $display_name = $row_name['username'];
        $profile_pic = $row_name['profile_pic'] ?: 'default_user.png';
    }
} elseif ($firm_id) {
    $stmt_name = $conn->prepare("SELECT brand_name, profile_pic FROM firm WHERE ID = ?");
    $stmt_name->bind_param("i", $firm_id);
    $stmt_name->execute();
    $res_name = $stmt_name->get_result();
    if ($row_name = $res_name->fetch_assoc()) {
        $display_name = $row_name['brand_name'];
        $profile_pic = $row_name['profile_pic'] ?: 'default_firm.png';
    }
}

    $msg = $_GET['msg'] ?? null;

    $search_query = $_GET['search'] ?? '';
    $selected_cat = $_GET['cat'] ?? '';

    $sql = "SELECT p.*, f.brand_name,
        (SELECT COUNT(*) FROM favorites WHERE user_id = $user_id AND product_id = p.ID) as is_fav,
        (SELECT COUNT(*) FROM shopping_list WHERE user_id = $user_id AND product_id = p.ID) as is_in_cart
        FROM products p
        LEFT JOIN firm f ON p.firm_id = f.ID
        WHERE p.active = 1 AND p.approved = 1";
    
        $limit = 8; 
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $offset = ($page - 1) * $limit;

    // Összes sor kiszámolása a szűrőkkel
    $count_sql = "SELECT COUNT(*) as total FROM products p LEFT JOIN firm f ON p.firm_id = f.ID WHERE p.active = 1 AND p.approved = 1";
    if ($selected_cat !== '') $count_sql .= " AND p.type = '" . $conn->real_escape_string($selected_cat) . "'";
    if ($search_query !== '') $count_sql .= " AND (p.name LIKE '%$search_query%' OR f.brand_name LIKE '%$search_query%')";

    $count_res = $conn->query($count_sql);
    $totalRows = $count_res->fetch_assoc()['total'];
    $totalPages = ceil($totalRows / $limit);

    $sql .= " LIMIT $limit OFFSET $offset";

    if ($selected_cat !== '') {
    $sql .= " AND p.type = '" . $conn->real_escape_string($selected_cat) . "'";
    }
    if ($search_query !== '') {
    $sql .= " AND (p.name LIKE ? OR f.brand_name LIKE ?)";
    $stmt = $conn->prepare($sql);
    $term = "%$search_query%";
    $stmt->bind_param("ss", $term, $term);
    $stmt->execute();
    $result = $stmt->get_result();
    }else {
    $result = $conn->query($sql);
    }

?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SzuperShop - Főoldal</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root { 
            --primary: #2c3e50; 
            --accent: #3498db; 
            --success: #27ae60; 
            --danger: #e74c3c; 
        }

        body { 
            font-family: 'Segoe UI', sans-serif; 
            background: #f8f9fa; 
            margin: 0; 
        }

        header { 
            background: var(--primary); 
            color: white; 
            padding: 0.8rem 5%; 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            position: sticky; 
            top: 0; 
            z-index: 1000; 
            box-shadow: 0 2px 10px rgba(0,0,0,0.2); 
            flex-wrap: wrap;
            gap: 15px;
        }

        .logo { 
            font-size: 1.5rem; 
            font-weight: bold; 
            white-space: nowrap;
        }

        .search-container { 
            flex-grow: 1; 
            max-width: 700px; 
        }
        .search-form {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .search-box { 
            position: relative; 
            flex-grow: 1;
        }
        .search-box input { 
            width: 100%; 
            padding: 10px 15px 10px 40px; 
            border-radius: 25px; 
            border: none; 
            outline: none; 
            box-sizing: border-box;
        }
        .search-box i { 
            position: absolute; 
            left: 15px; top: 50%; 
            transform: translateY(-50%); 
            color: #7f8c8d; 
        }

        #cat-select {
            padding: 10px 15px 10px 35px;
            border-radius: 25px;
            border: 1px solid rgba(255,255,255,0.2);
            background: rgba(255,255,255,0.1);
            color: white;
            cursor: pointer;
            appearance: none;
        }
        nav { 
            display: flex; 
            gap: 15px; 
            align-items: center;  
        }
        nav a { 
            color: white; 
            text-decoration: none; 
            text-align: center;
            font-size: 0.8rem;
        }

        /* Profil rész a nav-ban */
        .user-profile {
            display: flex !important;
            align-items: center;
            gap: 8px;
            background: rgba(255,255,255,0.1);
            padding: 5px 12px;
            border-radius: 25px;
        }
        .nav-profile-img {
            width: 30px; height: 30px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--accent);
        }

        .container { 
            max-width: 1400px; 
            margin: 30px auto; 
            padding: 0 20px; 
            display: grid; 
            /* Monitoron 4-5 oszlop, mobilon 2 oszlop */
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr)); 
            gap: 25px; 
        }

        .card { 
            background: white; 
            border-radius: 15px; 
            padding: 15px; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.05); 
            text-align: center;
            display: flex; 
            flex-direction: column; 
            height: 100%;
            transition: 0.3s;
            box-sizing: border-box;
        }

        .card:hover { transform: translateY(-5px); }

        .card-content {
            flex-grow: 1; /* Ez a rész kitölti a maradék helyet, tolva a footert lefelé */
            display: flex;
            flex-direction: column;
        }
        .card h4 {
            margin: 10px 0;
            font-size: 1.1rem;
        }
        .card-footer-wrapper {
            margin-top: auto; /* Ez a kulcs: az aljára tolja a blokkot */
            padding-top: 10px;
        }
        .card-actions { 
            display: flex; 
            justify-content: center; 
            gap: 25px; 
            margin-top: 5px; 
            padding-top: 10px; 
            border-top: 1px solid #eee;
        }
        .card img { 
            width: 100%;
            height: 120px;
            object-fit: contain;
        }
        .search-form {
            display: flex;
            gap: 10px !important; /* A korábbi 80px helyett */
            width: 100%;
        }
        .price-tag { 
            font-size: 1.3rem; 
            font-weight: bold; 
            color: var(--success); 
            margin: 10px 0 ; 
            margin-top: auto; 
        }
        .btn-cart { 
            display: block; 
            background: var(--primary); 
            color: white; 
            padding: 10px; 
            border-radius: 8px; 
            text-decoration: none; 
            margin-top: 15px; 
        }
        .brand_name { 
            margin-top: auto; 
        }
        @media (max-width: 900px) {
            header { flex-wrap: wrap; justify-content: center; }
            .search-container { order: 3; width: 100%; }
            .container { grid-template-columns: repeat(2, 1fr); gap: 15px; padding: 10px; }
            .user-name { display: none; }
        }
        
    </style>
</head>
<body>

<header>
    <div class="logo">
        <i class="fas fa-shopping-bag"></i> SzuperShop
    </div>

    <div class="search-container">
        <form action="index.php" method="GET" style="display: flex; gap: 80px; width: 100%; max-width: 600px;">
            <div class="search-box" style="flex-grow: 1;">
                <i class="fas fa-search"></i>
                <input type="text" name="search" placeholder="Keresés a termékek között..." value="<?= htmlspecialchars($search_query) ?>">
            </div>
                
            <div style="position: relative; min-width: 50px;">
            <label for="cat-select" style="position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: white; cursor: pointer; z-index: 10;">
                <i class="fas fa-bars"></i>
            </label>
            <select name="cat" id="cat-select" onchange="this.form.submit()" 
                style="padding: 10px 15px 10px 40px; border-radius: 25px; border: 1px solid rgba(255,255,255,0.2); 
                       background: rgba(255,255,255,0.1); color: white; outline: none; cursor: pointer; appearance: none; width: 150px; font-size: 0.85rem;">
                <option value="" style="color: black;">Kategóriák</option>
                    <?php
                    $categories = ['Zöldség és gyümölcs', 'Tejtermék- tojás', 'Pékáru', 'Húsáru', 'Mélyhűtött', 'Alapvető élelmiszerek', 'Italok', 'Speciális', 'Háztartás', 'Drogéria', 'Kisállat', 'Otthon-hobbi'];
                    foreach ($categories as $cat): ?>
                <option value="<?= $cat ?>" <?= $selected_cat == $cat ? 'selected' : '' ?> style="color: black;">
                    <?= $cat ?>
                </option>
                <?php endforeach; ?>
            </select>
            </div>
        </form>
    </div>

    <nav>
    <?php if($user_id || $firm_id): ?>
        <a href="profile.php" class="user-profile" title="Profil szerkesztése">
            <img src="uploads/profiles/<?= $profile_pic ?>" class="nav-profile-img" alt="Profil">
            <span class="user-name" style="display: inline; font-size: 0.9rem;"><?= htmlspecialchars($display_name) ?></span>
        </a>

        <?php if($role === 'admin'): ?>
            <a href="admin.php" title="Adminisztráció"><i class="fas fa-user-shield"></i><span>Admin</span></a>
        <?php endif; ?>
        
        <?php if(!$firm_id): ?>
            <a href="favorites.php" title="Kedvencek"><i class="fas fa-heart"></i><span>Kedvenc</span></a>
            <a href="cart_page.php" title="Kosár"><i class="fas fa-shopping-cart"></i><span>Kosár</span></a>
        <?php else: ?>
            <a href="firm_dashboard.php" title="Irodám"><i class="fas fa-store"></i><span>Irodám</span></a>
        <?php endif; ?>
        
        <a href="logout.php" title="Kilépés" style="color: var(--danger);"><i class="fas fa-sign-out-alt"></i><span>Kilépés</span></a>
    <?php else: ?>
        <a href="login.php" title="Bejelentkezés"><i class="fas fa-user"></i><span>Belépés</span></a>
        <a href="register.php" title="Regisztráció"><i class="fas fa-user-plus"></i><span>Regisztráció</span></a>
    <?php endif; ?>
</nav>
</header>

<?php
$cat_res = $conn->query("SELECT 'type' FROM products ORDER BY name ASC");
?>

<div class="container">
    <?php if ($result->num_rows > 0): ?>
        <?php while($row = $result->fetch_assoc()): ?>
    <div class="card">
        <div class="card-actions">
                    </div>
    <a href="description.php?id=<?= $row['ID'] ?>" style="text-decoration: none; color: inherit;">
        <img src="uploads/<?= $row['picture'] ?: 'no_image.jpg' ?>" alt="termék">
        <h4><?= htmlspecialchars($row['name']) ?></h4>
    </a>

    <div class="spacer"></div>

    <div class="card-footer">
        <p class="brand-name"><?= htmlspecialchars($row['brand_name'] ?: 'Saját termék') ?></p>
        <div class="price-tag"><?= number_format($row['price'], 0, ',', ' ') ?> Ft</div>
    </div>

    <div class="card-actions">
        <?php if ($row['is_fav'] > 0): ?>
            <a href="cart_actions.php?remove_fav=<?= $row['ID'] ?>" title="Eltávolítás a kedvencekből">
                <i class="fa-solid fa-heart" style="color: #e74c3c; font-size: 1.4rem;"></i>
            </a>
        <?php else: ?>
            <a href="cart_actions.php?add_to_fav=<?= $row['ID'] ?>" title="Kedvencekhez adom">
                <i class="fa-regular fa-heart" style="color: #ccc; font-size: 1.4rem;"></i>
            </a>
        <?php endif; ?>

        <?php if ($row['is_in_cart'] > 0): ?>
            <a href="cart_page.php" title="Már a kosárban van">
                <i class="fa-solid fa-cart-shopping" style="color: #27ae60; font-size: 1.4rem;"></i>
            </a>
        <?php else: ?>
            <a href="cart_actions.php?add_to_cart=<?= $row['ID']?>?>" title="Kosárba teszem">
                <i class="fa-solid fa-cart-plus" style="color: #ccc; font-size: 1.4rem;"></i>
            </a>
        <?php endif; ?>
        </div>
        </div><?php endwhile; ?>
    <?php else: ?>
        <p style="text-align:center; grid-column: 1/-1;">Nincs a keresésnek megfelelő termék.</p>
    <?php endif; ?>
    </div> <?php if ($totalPages > 1): ?>
    <div style="padding: 20px; display: flex; justify-content: center; gap: 5px;">
        <?php
        function getPageUrl($pageNum) {
            $params = $_GET;
            $params['page'] = $pageNum;
            return '?' . http_build_query($params);
        }
        ?>
        </div>
<?php endif; ?>
</div>
</body>
</html>